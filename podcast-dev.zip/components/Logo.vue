<template>
  <div class="logo">
    <img src="images/logo.svg" alt="" />
  </div>
</template>
<style>
.NuxtLogo {
  animation: 1s appear;
}

@keyframes appear {
  0% {
    opacity: 0;
  }
  100% {
    opacity: 1;
  }
}
</style>
