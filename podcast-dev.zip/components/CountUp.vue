<template>
  <i-countup
    :endVal="endVal"
    :delay="delay"
    @ready="onReady"
    v-scroll="onScroll"
  />
</template>

<script>
export default {
  props: {
    endVal: {
      type: Number,
      required: true
    },
    delay: {
      type: Number,
      default: 1
    }
  },
  methods: {
    onReady(instance, CountUp) {
      //   window.addEventListener('scroll', () => {
      //     const windowPos = window.scrollY + window.innerHeight
      //     const elOffset = window.elOffset(el)
      //     if (elOffset.top < windowPos) {
      //     }
      //   })
    }
  }
}
</script>

<style lang="scss" scoped></style>
