import Vue from 'vue'
import ICountup from 'vue-countup-v2'

Vue.component('i-countup', ICountup)

Vue.directive('scroll', {
  inserted(el, binding) {
    const f = function(evt) {
      if (binding.value(evt, el)) {
        window.removeEventListener('scroll', f)
      }
    }
    window.addEventListener('scroll', f)
  }
})
